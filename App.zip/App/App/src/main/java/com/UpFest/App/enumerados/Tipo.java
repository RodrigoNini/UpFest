package com.UpFest.App.enumerados;

public enum Tipo {

    GASTO,
    CARREGAMENTO;



}
