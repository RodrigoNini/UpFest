package com.UpFest.App.controllers;

public class VendasController {
}
