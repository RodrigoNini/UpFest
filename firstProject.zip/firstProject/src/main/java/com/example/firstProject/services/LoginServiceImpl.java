package com.example.firstProject.services;

import com.example.firstProject.entities.User;
import org.springframework.stereotype.Service;

@Service
public class LoginServiceImpl implements LoginService {
    @Override
    public boolean validateLogin(User user) {
        if (user.getUsername().equals("quimBarreiros") && user.getPassword().equals("paloco")) {
            return true;
        }
        return false;
    }
}
