package com.example.firstProject.services;

import com.example.firstProject.entities.Task;
import com.example.firstProject.entities.User;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.ArrayList;

@Service
public class TasksServiceImp implements TasksService {

    ArrayList<Task> innerTasks = new ArrayList<>();
    Task one = new Task(0, "First Task", "2023");

    @Override
    public ArrayList<Task> getAllTasks() {
        innerTasks.add(one);
        return innerTasks;
    }

    @Override
    public ArrayList<Task> getUserTasks(User user) {
        return user.getUserTasks();
    }

    @Override
    public Task getUserTask(User user, Integer id) {
        return user.getUserTasks().get(id);
    }

    @Override
    public void newTask(User user, Integer taskId, String taskName, String taskDate) {
        user.getUserTasks().add(new Task(taskId, taskName, taskDate));
        System.out.println(user);
    }

    @Override
    public void deleteTaskID(User user, Integer id) {
        System.out.println("Deleting " + user.getUserTasks().get(id).getName());
        user.getUserTasks().remove(id);
    }
}
