package com.example.firstProject.services;

import com.example.firstProject.entities.Task;
import com.example.firstProject.entities.User;

import java.util.ArrayList;

public interface TasksService {

    ArrayList<Task> getAllTasks();

    ArrayList<Task> getUserTasks(User user);

    Task getUserTask (User user, Integer id);

    void newTask (User user, Integer id, String name, String date);

    void deleteTaskID(User user, Integer id);



}
