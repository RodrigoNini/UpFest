package com.example.firstProject.services;

import com.example.firstProject.entities.User;

public interface LoginService {
    public boolean validateLogin(User user);
}
