package com.example.firstProject.controllers;

import com.example.firstProject.entities.Task;
import com.example.firstProject.entities.User;
import com.example.firstProject.services.LoginService;
import com.example.firstProject.services.TasksService;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Date;

import static org.springframework.data.jpa.domain.AbstractPersistable_.id;

@Controller
@Component
public class HomeController {

    @Autowired
    LoginService loginService;

    @Autowired
    TasksService tasksService;

    @GetMapping(value = "/")
    public String homePage() {
        return "index";
    }

    @PostMapping(value = "/login")
    @ResponseBody
    public void login(@RequestBody User user) {

        System.out.println(user);

        if (loginService.validateLogin(user)) {
            System.out.println("Accepted " + new Date());
        } else {
            System.out.println("NOT Accepted " + new Date());
        }
    }

    @GetMapping(value = "/tasks")
    @ResponseBody
    public String tasks(@RequestBody User user) {

        String tasks = "";
        System.out.println("Getting user tasks...");

        for (Task task : tasksService.getUserTasks(user)) {
            tasks += task.getId() + " - " + task.getName() + " - " + task.getDate() + "\r";
        }

        return tasks;
    }

    @GetMapping(value = "/tasks/{id}")
    @ResponseBody
    public String tasksID(@PathVariable Integer id, @RequestBody User user) {

        String taskInfo = "";
        Task task = tasksService.getUserTask(user, id);

        taskInfo += task.getId() + " ";
        taskInfo += task.getName() + " ";
        taskInfo += task.getDate() + " ";

        return taskInfo;
    }

    @PostMapping(value = "/tasks/new")
    public void newTask(@RequestBody String newTaskInfo) {
        // Create request with user and new task info
        // Decode request to populate user
        JSONObject ob = new JSONObject(newTaskInfo);

        Integer taskId = ob.getInt("id");
        String taskName = ob.getString("name");
        String taskDate = ob.getString("date");

        String username = ob.getJSONObject("user").getString("username");
        String password = ob.getJSONObject("user").getString("password");

        User currentUser = new User(username, password, "A", "Z", new ArrayList<>() );

        tasksService.newTask(currentUser, taskId, taskName, taskDate);
    }

    @PostMapping(value = "/tasks/{id}/delete")
    @ResponseBody
    public void deleteTaskId(@PathVariable Integer id, @RequestBody User user) {
        tasksService.deleteTaskID(user, id);
    }
}

